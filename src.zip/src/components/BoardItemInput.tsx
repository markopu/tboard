import * as React from 'react'
import styled from 'styled-components'
import { useEffect, useState } from "react";

interface IBoardItemInputProps {
    value: string
  onChange : (e: React.ChangeEvent<HTMLInputElement>) => void
}

const Input = styled.input`
    font: 14px sans-serif;
    background: #e5eff5;
    border-radius: 3px;
`

const Text = styled.div`
    font: 14px sans-serif;
`

export const BoardItemInput: React.FunctionComponent<IBoardItemInputProps> = props => {
    const [active, setActive] = useState(false)

    const hEnter = () => {
      setActive(false)
    }
    const hKeyPress = (target: React.KeyboardEvent<HTMLInputElement>) => {
        if (target.charCode === 13) {
            console.log('... enter pressed')
            hEnter()
        }
    }

    useEffect(() => {
      if (props.value.length === 0) setActive(true)
    },[])

    return (
        <>
            {active ? (
                <Input
                    onBlur={() => hEnter()}
                    value={props.value}
                    onKeyPress={hKeyPress}
                    onChange={props.onChange}
                />
            ) : (
                <Text onClick={() => setActive(true)}>{props.value}</Text>
            )}
        </>
    )
}
