import * as React from 'react'
import styled from 'styled-components'

interface INewBoardInputProps {
    title: string
    onEnter: () => void
    onChange : (e: React.ChangeEvent<HTMLInputElement>) => void
}

interface INewBoardInputStyleProps {
    inputColor?: string
}

const Input = styled.input<INewBoardInputStyleProps>`
    padding: 0.5em;
    margin: 0.5em;
    background: papayawhip;
    border: none;
    border-radius: 3px;
`

export const NewBoardInput: React.FunctionComponent<INewBoardInputProps> = props => {
    const hKeyPress = (target: React.KeyboardEvent<HTMLInputElement>) => {
        if (target.charCode === 13) {
            console.log('... enter pressed')
            props.onEnter()
        }
    }

    return <Input
      value={props.title}
      onKeyPress={hKeyPress}
      onChange={props.onChange}
      placeholder={"Add new list ..."}
    />
}
