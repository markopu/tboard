import * as React from "react";
import styled from "styled-components";

interface IBoardButtonProps {

};


const BButton = styled.div`
  background-color: light-blue
`;

export const BoardButton: React.FunctionComponent<IBoardButtonProps> = (props) => {
  return (
    <>

    </>
  );
};